<?php
// Consistency is the kye to success