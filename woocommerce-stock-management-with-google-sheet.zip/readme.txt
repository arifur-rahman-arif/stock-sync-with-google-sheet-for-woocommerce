=== WooCommerce Stock Management with Google Sheet ===
Contributors: wppool, devdrarif
Tags: woocommerce, google-sheet, stocks, store
Requires at least: 5.4
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



=== Description ===

***WooCommerce Stock Management with Google Sheet*** plugin allows you to manage your products from google sheet in real-time.
It offers users to update WooCommerce products data from google sheet. With this plugin, the WooCommerce products are synchronized in bi-directional.
That means either you change your data in WordPress or in Google Sheet, the data will be updated in both places.


== Changelog ==

= 1.0.0 =
* Fixed: Fixed tab management db update